death_screen = """
██    ██  ██████  ██    ██     ██████  ██ ███████ ██████      
 ██  ██  ██    ██ ██    ██     ██   ██ ██ ██      ██   ██     
  ████   ██    ██ ██    ██     ██   ██ ██ █████   ██   ██     
   ██    ██    ██ ██    ██     ██   ██ ██ ██      ██   ██     
   ██     ██████   ██████      ██████  ██ ███████ ██████     
"""

snake_logo = """
███████ ███    ██  █████  ██   ██ ███████  
██      ████   ██ ██   ██ ██  ██  ██      
███████ ██ ██  ██ ███████ █████   █████   
     ██ ██  ██ ██ ██   ██ ██  ██  ██      
███████ ██   ████ ██   ██ ██   ██ ███████ 
"""

help_text = """
Every time you eat a fruit, you become bigger, and is more hard to predict your snake move.

You win the game if you complete all the space with snake.

controls are press w for up direction,s for down direction,d for right direction and a for left direction
"""

win_screen = """


██    ██  ██████  ██    ██     ██     ██ ██ ███    ██ ██ 
 ██  ██  ██    ██ ██    ██     ██     ██ ██ ████   ██ ██ 
  ████   ██    ██ ██    ██     ██  █  ██ ██ ██ ██  ██ ██ 
   ██    ██    ██ ██    ██     ██ ███ ██ ██ ██  ██ ██    
   ██     ██████   ██████       ███ ███  ██ ██   ████ ██ 
                                                         
                                                         


"""

controls = """
  press w
"""